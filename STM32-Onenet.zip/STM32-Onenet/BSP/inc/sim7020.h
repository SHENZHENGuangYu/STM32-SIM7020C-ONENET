#ifndef __SIM7020_H
#define __SIM7020_H

/*�궨��*/

#define SIM7020_AT_0x0A_NUM                          2 //AT
#define SIM7020_AT_CSQ_0x0A_NUM                      4 //AT+CSQ
#define SIM7020_AT_GSN_0x0A_NUM                      4 //AT+GSN
#define SIM7020_AT_CREG_0x0A_NUM                     4 //AT+CREG?
#define SIM7020_AT_CGATT_0x0A_NUM                    4 //AT+CGATT

#define SIM7020_AT_CSOC_0x0A_NUM                     4 //AT+CSOC
#define SIM7020_AT_CSOCON_0x0A_NUM                   2 //AT+CSOCON
#define SIM7020_AT_CSODSEND_0x0A_NUM                 3 //AT+CSODSEND
#define SIM7020_AT_CSORCVFLAG_0x0A_NUM               2 //AT+CSORCVFLAG
#define SIM7020_AT_CSOSENDFLAG_0x0A_NUM              2 //AT+CSOSENDFLAG
#define SIM7020_AT_CSOCL_0x0A_NUM                    2 //AT+CSOCL
#define SIM7020_SEND_DATA_0x0A_NUM                   4 //DATA ACCEPT:xx
#define SIM7020_AT_CSOSTATUS_0x0A_NUM                4 //AT+CSOSTATUS



#define SIM7020_PowerKey_High           GPIO_SetBits(GPIOA, GPIO_Pin_11)
#define SIM7020_PowerKey_Low            GPIO_ResetBits(GPIOA, GPIO_Pin_11)


#define signal_quality_max             31
#define signal_quality_min             1


extern char IMEI[16];

void SIM7020_GPIO_Configuration(void);
void SIM7020_Power_On(void);
void SIM7020_Power_Off(void);
void SIM7020_SoftReset(void);
unsigned char SIM7020_Init(void);
unsigned char SIM7020_GetIMEI(char *IMEI);
unsigned char SIM7020_GetSignalQuality(unsigned char *signal_quality);

unsigned char SIM7020_TCP_Connect(char *ip_address, unsigned int port);
unsigned char SIM7020_TCP_SendData(char *data, unsigned int data_len);
unsigned char SIM7020_TCP_Close(void);
unsigned char SIM7020_TCP_Connect_Status(void);


unsigned char SIM7020_Creat_TCP_UDP_Socket(unsigned char socket_id, unsigned char domain, 
                                                  unsigned char type, unsigned char protocol);

unsigned char SIM7020_Connect_Socket_To_Remote_Address_Port(unsigned char socket_id, char *remote_port,
                                                                   char *remote_address);

unsigned char SIM7020_Send_Data_To_Remote_Via_Socket(unsigned char socket_id, char *data, unsigned int data_len);


#endif