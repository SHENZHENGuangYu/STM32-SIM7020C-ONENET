#include "stm32f10x.h"
#include "delay_interface.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "net_dev_at_cmd_interface.h"
#include "net_dev_downlink_data_interface.h"
#include "sim7020.h"

char IMEI[16]={0};
/**-----------------------------------------------------------------------------
  * @���  SIM7020 GPIO����
  * @����  ��
  * @����  ��
  */
void SIM7020_GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  
  
  /*����SIM7020 PowerKey����*/ 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
    
  //��ʼ��Ϊ�͵�ƽ
  SIM7020_PowerKey_Low;
  
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020����
  * @����  ��
  * @����  ��
  */
void SIM7020_Power_On(void)
{
  /*�����ź�*/
  
  SIM7020_PowerKey_Low;
  Delay_ms(800);
  SIM7020_PowerKey_High;
  Delay_ms(1500);
  SIM7020_PowerKey_Low;
 
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020�ػ�
  * @����  ��
  * @����  ��
  */
void SIM7020_Power_Off(void)
{
  /*�ػ��ź�*/
  
  SIM7020_PowerKey_Low;
  Delay_ms(800);
  SIM7020_PowerKey_High;
  Delay_ms(2500);
  SIM7020_PowerKey_Low;
  
}


/**-----------------------------------------------------------------------------
  * @���  SIM7020������λ
  * @����  ��
  * @����  ��
  */
void SIM7020_SoftReset(void)
{
  
  NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CRESET\r\n", " ", 1, 10);
  //Delay_ms(10000);
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020��ʼ��
  * @����  ��
  * @����  1
  */
unsigned char SIM7020_Init(void)
{ 
  unsigned char res = 0, t;
  unsigned char signal_quality = 0;
  

  //�ȴ��ź��ȶ�
  t = 60;
  while(t--)
  {
    res = SIM7020_GetSignalQuality(&signal_quality);
    if(res == 0 && signal_quality > 0)
      break; 
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;
  
  }
  
  //��ȡIMEI��5�β��ɹ��򷵻ش���

  t = 5;
  while(t--)
  {
    res = SIM7020_GetIMEI(IMEI); //��ȡ����
    if(res == 0)
      break;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }

  
  //��ѯ�Ƿ�ע�ᵽ����
  t = 50;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CREG?\r\n", "0,6", SIM7020_AT_CREG_0x0A_NUM, 5);
    if(res == 0)
      break;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }

  
  //��ѯ�Ƿ�������
  t = 50;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CGATT?\r\n", "1", SIM7020_AT_CGATT_0x0A_NUM, 5);
    if(res == 0)
      break;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }
  
 //�����������ݽ��ո�ʽΪ�ַ���
  t = 5;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CSORCVFLAG=1\r\n", "OK", SIM7020_AT_CSORCVFLAG_0x0A_NUM, 5);
    if(res == 0)
      break;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }
  
  
  //���÷����������ݱ�־
  t = 5;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CSOSENDFLAG=1\r\n", "OK", SIM7020_AT_CSOSENDFLAG_0x0A_NUM, 5);
    if(res == 0)
      break;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }
  
  
  return 0;
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020��ȡ�ź�������0~31��
  * @����  signal_quality���ź�����
  * @����  NetDev_AtCmd.AtCmdRespBuff������Դ����
  * @����  �ź�������ȡ���
  */
unsigned char SIM7020_GetSignalQuality(unsigned char *signal_quality)
{
  unsigned char cnt = 0;
  unsigned char res = 0;
  
  res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CSQ\r\n", ",", SIM7020_AT_CSQ_0x0A_NUM, 5);
  if(res != 0)
    return 1;
  
  /*�����ź�����*/
  for(cnt=0; cnt<50; cnt++)
  {
    if( NetDev_AtCmd.AtCmdRespBuff[cnt] == ':')
    { 
      *signal_quality = NetDev_AtCmd.AtCmdRespBuff[cnt+2] - '0';
    }
    
    if( NetDev_AtCmd.AtCmdRespBuff[cnt+4] == ',')
    {  
      *signal_quality = (*signal_quality) * 10 + NetDev_AtCmd.AtCmdRespBuff[cnt+3] - '0';
      break;
    }
  }
  
  //�ж��ź������Ƿ�Ϸ�
  if(*signal_quality > 31) 
    return 1;
  
  else
    return 0;
  
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020��ȡIMEI
  * @����  ��
  * @����  ��ȡ�����0���ɹ���1�����ɹ�
  */
unsigned char SIM7020_GetIMEI(char *IMEI)
{
  unsigned char i = 0 , j = 0;
  unsigned char res = 0;
  unsigned char imei_start = 0;
  
  res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+GSN\r\n", "OK", SIM7020_AT_GSN_0x0A_NUM, 5);
  if(res !=0 )
    return 1;
  
  //Ѱ�һ��з�
  for(i=0; i<100; i++)
  {
    if( NetDev_AtCmd.AtCmdRespBuff[i] >= '0' && imei_start == 0)
    {
      imei_start = 1;
      j = 0;
    }
    
    if(imei_start == 1 && (NetDev_AtCmd.AtCmdRespBuff[i] >= '0' && NetDev_AtCmd.AtCmdRespBuff[i] <= '9'))
    {
      IMEI[j] = NetDev_AtCmd.AtCmdRespBuff[i];
      
      if(j == 14)
        break;
      
      j++;
        
    }
    
  }
  
  
  IMEI[15] = 0;
  
  return RESP_OK;
}


/**-----------------------------------------------------------------------------
  * @���  SIM7020��������Ͽ�TCP����
  * @����  data������������ָ��
  * @����  data_len�����������ݳ���
  * @����  ���ͽ����0���ɹ���1��ʧ��
  */
unsigned char SIM7020_TCP_Close(void)
{
  unsigned char t;
  unsigned char res = 0;
  
  t = 5;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CSOCL=0\r\n", "OK", SIM7020_AT_CSOCL_0x0A_NUM, 10);
    if(res == RESP_OK)
      return 0;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }
  
  return 1;
}


/**-----------------------------------------------------------------------------
  * @���  SIM7020�������TCP����״̬
  * @����  ��
  * @����  ����״̬��0��������1���Ͽ�
  */
unsigned char SIM7020_TCP_Connect_Status(void)
{
  unsigned char t;
  unsigned char res = 0;
  
  t = 5;
  while(t--)
  {
    res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, "AT+CSOSTATUS=0\r\n", "0,2", SIM7020_AT_CSOSTATUS_0x0A_NUM, 10);
    if(res == RESP_OK)
      return 0;
    else
      Delay_ms(1000);
    if(t == 0)
      return 1;   
  }
}


unsigned char SIM7020_Creat_TCP_UDP_Socket(unsigned char socket_id, unsigned char domain, 
                                                  unsigned char type, unsigned char protocol)
{
  /*
    AT+CSOC=<socket_id>,<domain>,<type>,<protocol>[,<cid>]
  */
  unsigned char res;
  char send_str[200] = {0};
  char value_str[5] = {0};
  
  sprintf(value_str, "%d", socket_id);
  strcpy(send_str, "AT+CSOC=");
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, ",");
  sprintf(value_str, "%d", domain);
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, ",");
  sprintf(value_str, "%d", type);
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, ",");
  sprintf(value_str, "%d", protocol);
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, "\r\n");
  
  
  res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, send_str, "+CSOC:", SIM7020_AT_CSOC_0x0A_NUM, 10);
  
  return res;
}



unsigned char SIM7020_Connect_Socket_To_Remote_Address_Port(unsigned char socket_id, char *remote_port,
                                                                 char *remote_address)
{
 
  
  unsigned char res;
  char send_str[200] = {0};
  char value_str[5] = {0};
  
  sprintf(value_str, "%d", socket_id);
  strcpy(send_str, "AT+CSOCON=");
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, ",");
  strcat(send_str, remote_port);
  
  strcat(send_str, ",\"");
  strcat(send_str, remote_address);
  strcat(send_str, "\"");
  strcat(send_str, "\r\n");
  
  res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, send_str, "OK", SIM7020_AT_CSOCON_0x0A_NUM, 20);
  
  return res;
  
}


unsigned char SIM7020_Send_Data_To_Remote_Via_Socket(unsigned char socket_id, char *data, unsigned int data_len)
{
 
  
  unsigned char res;
  char send_str[200] = {0};
  char value_str[5] = {0};
  
  sprintf(value_str, "%d", socket_id);
  strcpy(send_str, "AT+CSODSEND=");
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, ",");
  sprintf(value_str, "%d", data_len);
  strcat(send_str, value_str);
  value_str[0] = 0;
  
  strcat(send_str, "\r\n");
  
  res = NetDev_SendAtCmd_GetResp(&NetDev_AtCmd, send_str, ">", SIM7020_AT_CSODSEND_0x0A_NUM, 10);
  
  res = NetDev_SendData_GetResp(&NetDev_AtCmd, data, data_len, "SEND:", SIM7020_SEND_DATA_0x0A_NUM, 20);
  
  return res;
  
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020����ATָ����մ���
  * @����  DataBuff�����ڽ������ݳ�������
  * @����  NetDev_AtCmd�������豸ATָ����ṹ��
  * @����  CurrentRecvByte����ǰ�����ֽ�
  * @����  
  */
void SIM7020_AtCmd_RecvProcess( PrimaryUsartRecvData_TypeDef *PrimaryUsartRecvData, 
                                NetDev_AtCmd_TypeDef *NetDev_AtCmd, 
                                char CurrentRecvByte)

{ 
  //����Խ��
  if(PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize)
  {
    PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt] = CurrentRecvByte;
  }
  
  // ֻ��AT��������
  if(PrimaryUsartRecvData->DataLengthCnt >= 2 &&
     PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize && //����Խ��
     NetDev_AtCmd->AtCmdRespStart == 0 &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-2] == 'A' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-1] == 'T' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt  ] == 0x0D)
  {
    PrimaryUsartRecvData->DataLengthCnt = 0;
      
    NetDev_AtCmd->AtCmdRespStart = 1;
    NetDev_AtCmd->AtCmdRespBuff[0] = 'A';
    NetDev_AtCmd->AtCmdRespBuff[1] = 'T';
    NetDev_AtCmd->AtCmdRespBuff[2] = 0x0D;
    NetDev_AtCmd->AtCmdRespLengthCnt = 2;
    NetDev_AtCmd->ReturnCrLfCnt = 0;
  }
  
  // AT+xxxxָ�������
  if(PrimaryUsartRecvData->DataLengthCnt >= 2 &&
     PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize && //����Խ��
     NetDev_AtCmd->AtCmdRespStart == 0 &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-2] == 'A' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-1] == 'T' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt  ] == '+')
  {
    PrimaryUsartRecvData->DataLengthCnt = 0;
      
    NetDev_AtCmd->AtCmdRespStart = 1;
    NetDev_AtCmd->AtCmdRespBuff[0] = 'A';
    NetDev_AtCmd->AtCmdRespBuff[1] = 'T';
    NetDev_AtCmd->AtCmdRespBuff[2] = '+';
    NetDev_AtCmd->AtCmdRespLengthCnt = 2;
    NetDev_AtCmd->ReturnCrLfCnt = 0;
  }
    
  // ���ݷ��ͳɹ�����
  if(PrimaryUsartRecvData->DataLengthCnt >= 10 &&
     PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize && //����Խ��
     NetDev_AtCmd->AtCmdRespStart == 0 &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-10] == 'D' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-9]  == 'A' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-8]  == 'T' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-7]  == 'A' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-6]  == ' ' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-5]  == 'A' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-4]  == 'C' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-3]  == 'C' &&  
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-2]  == 'E' &&  
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-1]  == 'P' &&  
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt  ]  == 'T'  
       )
  {
    PrimaryUsartRecvData->DataLengthCnt = 0;
      
    NetDev_AtCmd->AtCmdRespStart = 1;
    NetDev_AtCmd->AtCmdRespBuff[0]  = 'D';
    NetDev_AtCmd->AtCmdRespBuff[1]  = 'A';
    NetDev_AtCmd->AtCmdRespBuff[2]  = 'T';
    NetDev_AtCmd->AtCmdRespBuff[3]  = 'A';
    NetDev_AtCmd->AtCmdRespBuff[4]  = ' ';
    NetDev_AtCmd->AtCmdRespBuff[5]  = 'A';
    NetDev_AtCmd->AtCmdRespBuff[6]  = 'C';
    NetDev_AtCmd->AtCmdRespBuff[7]  = 'C';
    NetDev_AtCmd->AtCmdRespBuff[8]  = 'E';
    NetDev_AtCmd->AtCmdRespBuff[9]  = 'P';
    NetDev_AtCmd->AtCmdRespBuff[10] = 'T';
    NetDev_AtCmd->AtCmdRespLengthCnt = 10;
    NetDev_AtCmd->ReturnCrLfCnt = 0;
  }

  // �����豸ATָ����Ӧ�ֽڿ�ʼ
  if(NetDev_AtCmd->AtCmdRespStart == 1)
  {
    //����Խ��
    if(NetDev_AtCmd->AtCmdRespLengthCnt < AtCmdRespBuffSize)
    {
      NetDev_AtCmd->AtCmdRespBuff[NetDev_AtCmd->AtCmdRespLengthCnt] = CurrentRecvByte;
    }
      
    if(NetDev_AtCmd->AtCmdRespLengthCnt < AtCmdRespBuffSize && //����Խ��
       NetDev_AtCmd->AtCmdRespBuff[NetDev_AtCmd->AtCmdRespLengthCnt - 1] == 0x0D && 
       NetDev_AtCmd->AtCmdRespBuff[NetDev_AtCmd->AtCmdRespLengthCnt]     == 0x0A) 
    {
      NetDev_AtCmd->ReturnCrLfCnt ++;
      if(NetDev_AtCmd->ReturnCrLfCnt == NetDev_AtCmd->NeedReturnCrLfNum)
      {
        NetDev_AtCmd->AtCmdRespOK = 1;
        NetDev_AtCmd->AtCmdRespStart = 0;
        NetDev_AtCmd->AtCmdRespLengthCnt = 0;
        NetDev_AtCmd->ReturnCrLfCnt = 0;
        
        //��մ��ڳ������ջ���
        PrimaryUsartRecvData->DataLengthCnt = 0;
      }
    }
         
    // ����"AT+CSODSEND="�����'>'���ܼ���������
    if(NetDev_AtCmd->AtCmdRespLengthCnt < AtCmdRespBuffSize && //����Խ��
       NetDev_AtCmd->AtCmdRespBuff[NetDev_AtCmd->AtCmdRespLengthCnt - 1] == '>' &&
       NetDev_AtCmd->AtCmdRespBuff[NetDev_AtCmd->AtCmdRespLengthCnt] == ' '
      )
    {
      NetDev_AtCmd->AtCmdRespOK = 1;
      NetDev_AtCmd->AtCmdRespStart = 0;
      NetDev_AtCmd->AtCmdRespLengthCnt = 0;
      NetDev_AtCmd->ReturnCrLfCnt = 0;
      
      PrimaryUsartRecvData->DataLengthCnt = 0;    
    }
      
    // �����ֽڼ���������
    if(NetDev_AtCmd->AtCmdRespLengthCnt < AtCmdRespBuffSize - 1)
      NetDev_AtCmd->AtCmdRespLengthCnt ++;
  }
  
}

/**-----------------------------------------------------------------------------
  * @���  SIM7020���շ�������������
  * @����  DataBuff�����ڽ������ݳ�������
  * @����  NetDev_AtCmd�������豸ATָ����ṹ��
  * @����  CurrentRecvByte����ǰ�����ֽ�
  * @����  
  */
static unsigned char downlink_data_indicate = 0; //��������ָʾ��־
static unsigned char first_comma_address = 0; //��һ�����ŵ�ַ
static unsigned char first_comma_flag = 0; //��һ�����ű�־
static unsigned char second_comma_flag = 0; //�ڶ������ű�־
static unsigned char second_comma_address = 0; //�ڶ������ŵ�ַ
static unsigned int downlink_data_len = 0;
#define downlink_data_len_str_size  10
static char downlink_data_len_str[downlink_data_len_str_size] = {0};

void SIM7020_DownlinkData_Receive(PrimaryUsartRecvData_TypeDef *PrimaryUsartRecvData, 
                                  NetDev_DownlinkData_TypeDef *NetDev_DownlinkData,
                                  char CurrentRecvByte)
{
  /*
     +CSONMI: 0,4,
  */
  
  //����Խ��
  if(PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize)
  {
    PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt] = CurrentRecvByte;
  }
  
  //�ж��Ƿ�Ϊ��������ָʾ
  if(downlink_data_indicate == 0 && 
     PrimaryUsartRecvData->DataLengthCnt >= 7 &&
     PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize && //����Խ��
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-7] == '+' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-6] == 'C' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-5] == 'S' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-4] == 'O' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-3] == 'N' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-2] == 'M' &&
     PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt-1] == 'I' &&
       PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt  ] == ':')
  {
    
    PrimaryUsartRecvData->DataBuff[0] = '+';
    PrimaryUsartRecvData->DataBuff[1] = 'C';
    PrimaryUsartRecvData->DataBuff[2] = 'S';
    PrimaryUsartRecvData->DataBuff[3] = 'O';
    PrimaryUsartRecvData->DataBuff[4] = 'N';
    PrimaryUsartRecvData->DataBuff[5] = 'M';
    PrimaryUsartRecvData->DataBuff[6] = 'I';
    PrimaryUsartRecvData->DataBuff[7] = ':';
    
    PrimaryUsartRecvData->DataLengthCnt = 7;
    
    downlink_data_indicate = 1;
    
    first_comma_flag = 0;
    second_comma_flag = 0;
    
  }
  
  //����Խ��
  if(downlink_data_indicate == 1 && PrimaryUsartRecvData->DataLengthCnt < PrimaryUsartRecvDataSize)
  {
    //��һ������
    if(PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt] == ',' && first_comma_flag == 0 && second_comma_flag == 0)
    {
      first_comma_address = PrimaryUsartRecvData->DataLengthCnt;
      first_comma_flag = 1;
    }
    
    //�ڶ�������
    if(PrimaryUsartRecvData->DataBuff[PrimaryUsartRecvData->DataLengthCnt - 1] == ',' && first_comma_flag == 1 && second_comma_flag == 0)
    {
      second_comma_address = PrimaryUsartRecvData->DataLengthCnt - 1;
      
      if(second_comma_address > first_comma_address && second_comma_address - first_comma_address + 2 <= downlink_data_len_str_size )
      {
        strncpy(downlink_data_len_str, &PrimaryUsartRecvData->DataBuff[first_comma_address + 1] , second_comma_address - first_comma_address - 1); 
        
        downlink_data_len = atoi(downlink_data_len_str);

        memset(downlink_data_len_str, 0, downlink_data_len_str_size);
      
        if(downlink_data_len <= Downlink_Data_Buff_Size)
        {
          downlink_data_indicate = 0;
          NetDev_DownlinkData->DataStart = 1;
          NetDev_DownlinkData->DataLengthCnt = 0;
          PrimaryUsartRecvData->DataLengthCnt = 0;
        }
      } 
    }
  }  
  
  if(NetDev_DownlinkData->DataStart == 1)
  {
    //����Խ��
    if(NetDev_DownlinkData->DataLengthCnt < Downlink_Data_Buff_Size)
      NetDev_DownlinkData->DataBuff[NetDev_DownlinkData->DataLengthCnt] = CurrentRecvByte;
      
    if(NetDev_DownlinkData->DataLengthCnt == downlink_data_len - 1)
    {
      NetDev_DownlinkData->DataRecvOK = 1;
      NetDev_DownlinkData->DataStart = 0;
      
      PrimaryUsartRecvData->DataLengthCnt = 0;
    }
    
    //����Խ��
    if(NetDev_DownlinkData->DataLengthCnt < Downlink_Data_Buff_Size - 1)
      NetDev_DownlinkData->DataLengthCnt ++;
  }
}
