#include "stm32f10x.h"
#include "stm32_usart.h"


/**
  * @��飺STM32ͨ������1����һ���ֽ�
  * @���룺��
  * @�������
  */
void STM32_USART1_SendByte(char data)
{
  while(USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET);//�˾����ӣ������׸������ֽڻᶪʧ
  USART_SendData(USART1, data);
  while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);  //�ȴ�������� 
  
}

/**
  * @��飺STM32ͨ������2����һ���ֽ�
  * @���룺��
  * @�������
  */
void STM32_USART2_SendByte(char data)
{
  while(USART_GetFlagStatus(USART2, USART_FLAG_TC)==RESET);//�˾����ӣ������׸������ֽڻᶪʧ
  USART_SendData(USART2, data);
  while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);  //�ȴ�������� 
  
}

/**
  * @��飺STM32ͨ������3����һ���ֽ�
  * @���룺��
  * @�������
  */
void STM32_USART3_SendByte(char data)
{
  while(USART_GetFlagStatus(USART3, USART_FLAG_TC)==RESET);//�˾����ӣ������׸������ֽڻᶪʧ
  USART_SendData(USART3, data);
  while(USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);  //�ȴ�������� 
  
}

/**
  * @��飺STM32 ����1��ʼ��
  * @���룺��
  * @�������
  */
void STM32_USART1_Init(unsigned int baud_rate)
{
  /****************************************************************************
  GPIO
  *****************************************************************************/
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  /****************************************************************************
  NVIC
  *****************************************************************************/
  NVIC_InitTypeDef NVIC_InitStructure;
  
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  /****************************************************************************
  USART
  *****************************************************************************/
  USART_InitTypeDef USART_InitStructure;  //���崮�ڽṹ
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); 
  
  USART_InitStructure.USART_BaudRate = baud_rate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART1, &USART_InitStructure);
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
  USART_Cmd(USART1, ENABLE);
}



/**
  * @��飺STM32 ����2��ʼ��
  * @���룺��
  * @�������
  */
void STM32_USART2_Init(unsigned int baud_rate)
{
  /****************************************************************************
  GPIO
  *****************************************************************************/
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  /****************************************************************************
  NVIC
  *****************************************************************************/
  
  
  NVIC_InitTypeDef NVIC_InitStructure;
  
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  
  /****************************************************************************
  USART
  *****************************************************************************/
  USART_InitTypeDef USART_InitStructure;  //���崮�ڽṹ
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); 
  
  USART_InitStructure.USART_BaudRate = baud_rate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART2, &USART_InitStructure);
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
  USART_Cmd(USART2, ENABLE);
}


/**
  * @��飺STM32 ����3��ʼ��
  * @���룺��
  * @�������
  */
void STM32_USART3_Init(unsigned int baud_rate)
{
  /****************************************************************************
  GPIO
  *****************************************************************************/
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
  
  USART_DeInit(USART3);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  /****************************************************************************
  NVIC
  *****************************************************************************/
  
  
  NVIC_InitTypeDef NVIC_InitStructure;
  
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  /****************************************************************************
  USART
  *****************************************************************************/
  USART_InitTypeDef USART_InitStructure;  //���崮�ڽṹ
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE); 
  
  USART_InitStructure.USART_BaudRate = baud_rate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART3, &USART_InitStructure);
 
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

  USART_Cmd(USART3, ENABLE);    
}