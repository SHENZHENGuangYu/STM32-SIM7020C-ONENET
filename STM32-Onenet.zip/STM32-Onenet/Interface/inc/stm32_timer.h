#ifndef __STM32_TIMER_H
#define __STM32_TIMER_H

void TIMER2_Init(void);
void TIMER2_RCC_Configuration(void);
void TIMER2_NVIC_Configuration(void);
void TIMER2_Configuration(void);

void TIMER3_Init(void);
void TIMER3_RCC_Configuration(void);
void TIMER3_NVIC_Configuration(void);
void TIMER3_Configuration(void);

void TIMER4_Init(void);
void TIMER4_RCC_Configuration(void);
void TIMER4_NVIC_Configuration(void);
void TIMER4_Configuration(void);


void TIMER2_On(void);
void TIMER2_Off(void);

void TIMER3_On(void);
void TIMER3_Off(void);

void TIMER4_On(void);
void TIMER4_Off(void);
#endif