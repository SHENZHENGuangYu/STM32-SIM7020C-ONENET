#ifndef __USART_H
#define __USART_H


//��������
void STM32_USART_Initialization(void);
void STM32_USART_Configuration(void);
void STM32_USART_NVIC_Configuration(void);
void STM32_USART_GPIO_Configuration(void);
void STM32_USART1_SendByte(char data);
void STM32_USART2_SendByte(char data);
void STM32_USART3_SendByte(char data);
void STM32_USART1_Init(unsigned int baud_rate);
void STM32_USART2_Init(unsigned int baud_rate);
void STM32_USART3_Init(unsigned int baud_rate);
#endif