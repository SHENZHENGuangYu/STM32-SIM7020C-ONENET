#ifndef __CONVERSION_H
#define __CONVERSION_H 

int strToHex(char *ch, char *hex);
int hexToStr(char *hex, char *ch);
int hexCharToValue(char ch);
char valueToHexCh(int value);
char *IntToStr(unsigned long int num, char str[]);
int tolower(int c) ;
int htoi(char s[]);

#endif