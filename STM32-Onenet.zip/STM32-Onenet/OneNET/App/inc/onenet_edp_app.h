#ifndef __ONENET_EDP_APP_H
#define __ONENET_EDP_APP_H

#include "onenet_edp_base.h"

//����Ϊ�ⲿ����
extern DATA_STREAM DataStreams[];
extern unsigned char DataStreamsCnt;

//����Ϊ�ⲿ����
extern OnenetEDPDevice_Def OnenetEDPDevice;

//��������

void OnenetDevice_Init(void);

char Onenet_Cmd_Analys_Do(char *cmd_buff);

char Set_DataUpdateCycle_Cmd_Analys_Do(char *cmd_buff, unsigned int cmd_len);

char Set_TrashHeight_Cmd_Analys_Do(char *cmd_buff, unsigned int cmd_len);
char Set_RefuseHeightAlarmUpper_Cmd_Analys_Do(char *cmd_buff, unsigned int cmd_len);
char Set_RefuseWeightAlarmUpper_Cmd_Analys_Do(char *cmd_buff, unsigned int cmd_len);
char Set_RefuseTemperatureAlarmUpper_Cmd_Analys_Do(char *cmd_buff, unsigned int cmd_len);


#endif