/**
  ******************************************************************************
  * @�ļ�  delay_interface.c
  * @����  guanghua
  * @�汾  V1.0
  * @����  2018-10-21
  * @���  �ṩ��ʱ�����ӿ�
  ******************************************************************************
  * @ע��
 
  ******************************************************************************
  */ 
#include "delay_interface.h"

//for STM32 @ 72MHz
void Delay_ms(unsigned int n_ms)
{ 
  unsigned int y;
  
  for(y=0;y<n_ms;y++)
  {
    Delay_us(1000);
  }
}   

//for STM32 @ 72MHz
void Delay_us(unsigned int n_us)
{ 
  unsigned int x, y;
  
  for(x=0;x<8;x++)
  {
    for(y=0;y<n_us;y++)
    {
      ;  
    }
  }
} 