#ifndef __NET_DEV_POWER_INTERFACE_H
#define __NET_DEV_POWER_INTERFACE_H



char NetDev_Power_On();
char NetDev_Power_Off();

#endif