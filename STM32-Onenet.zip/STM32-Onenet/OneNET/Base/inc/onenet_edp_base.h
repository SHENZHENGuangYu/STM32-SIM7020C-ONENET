#ifndef __ONENET_EDP_BASE_H
#define __ONENET_EDP_BASE_H

#include "net_dev_usart_interface.h"
#include "net_dev_downlink_data_interface.h"
#include "dStream.h"


#define ONENET_CMD_BUFF_SIZE   500

#define MAX_REMAIN_BYTES_LEN   2

//Onenet�ն�״̬����
typedef enum
{
  Online  = 1,
  Offline = 0,
} OnenetDeviceStatus_Def;


//OneNET�ն˶���
typedef struct
{
  const char DeviceID[15]; //�豸ID
  const char ApiKey[50]; //�豸APIKEY
  
  const char ProductID[15]; //��ƷID
  char AuthKey[50]; //�豸��Ȩ��Ϣ
  
  OnenetDeviceStatus_Def DeviceStatus;
  
  unsigned int PingCycle; //�����źŷ�������
  char TimeToPing; //���������ź�ʱ�䵽
  
  unsigned int UploadDataStreamsCycle; //�ϴ�����������
  char TimeToUploadDataStreams; //�ϴ�������ʱ�䵽
  
  char ConnectReqOK; //������Ӧ�ɹ�
  char PingReqOK;    //������Ӧ�ɹ�
  
  char *CmdBuff;
  char CmdRecvOK;
  
  char SaveOK;

} OnenetEDPDevice_Def;



char Onenet_EDP_Sever_Connect(void);

char Onenet_EDP_Connect(OnenetEDPDevice_Def *OnenetEDPDevice, 
                        NetDev_DownlinkData_TypeDef *NetDev_DownlinkData);

char Onenet_Offline_Reconnect(OnenetEDPDevice_Def *OnenetEDPDevice, 
                              NetDev_DownlinkData_TypeDef *NetDev_DownlinkData);

char Onenet_Disconnect(void);

char Onenet_Upload_Ping(OnenetEDPDevice_Def *OnenetEDPDevice, 
                        NetDev_DownlinkData_TypeDef *NetDev_DownlinkData);

char Onenet_Upload_Datastreams(OnenetEDPDevice_Def *OnenetEDPDevice, 
                               char *devid, 
                               DATA_STREAM *streamArray, 
                               unsigned short streamArrayCnt);

void Onenet_DownlinkData_PrimaryProcess(OnenetEDPDevice_Def *OnenetEDPDevice, 
                                        NetDev_DownlinkData_TypeDef *NetDev_DownlinkData);

#endif