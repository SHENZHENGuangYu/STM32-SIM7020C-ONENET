#ifndef __NET_DEV_INIT_INTERFACE_H
#define __NET_DEV_INIT_INTERFACE_H

char NetDev_Init(void);



#endif