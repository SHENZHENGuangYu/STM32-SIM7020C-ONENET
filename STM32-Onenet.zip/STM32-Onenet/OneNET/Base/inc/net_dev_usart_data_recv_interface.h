#ifndef __NET_DEV_USART_DATA_RECV_INTERFACE_H
#define __NET_DEV_USART_DATA_RECV_INTERFACE_H

#include "net_dev_usart_interface.h"
#include "net_dev_at_cmd_interface.h"
#include "net_dev_downlink_data_interface.h"




extern PrimaryUsartRecvData_TypeDef PrimaryUsartRecvData;


void NetDev_UsartData_Receive(PrimaryUsartRecvData_TypeDef *PrimaryUsartRecvData,
                              NetDev_AtCmd_TypeDef *NetDev_AtCmd, 
                              NetDev_DownlinkData_TypeDef *NetDev_DownlinkData, 
                              char CurrentRecvByte);



#endif