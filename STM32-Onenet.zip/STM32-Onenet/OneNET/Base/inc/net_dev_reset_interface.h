#ifndef __NET_DEV_RESET_INTERFACE_H
#define __NET_DEV_RESET_INTERFACE_H

char NetDev_Reset();



#endif