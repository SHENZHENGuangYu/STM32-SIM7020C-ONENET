#ifndef __NET_DEV_H
#define __NET_DEV_H

#include "sim7020.h"


#endif
