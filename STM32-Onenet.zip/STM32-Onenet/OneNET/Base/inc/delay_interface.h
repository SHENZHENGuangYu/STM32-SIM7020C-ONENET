#ifndef __DELAY_INTERFACE_H
#define __DELAY_INTERFACE_H


void Delay_us(unsigned int n_us);
void Delay_ms(unsigned int n_ms); 

#endif