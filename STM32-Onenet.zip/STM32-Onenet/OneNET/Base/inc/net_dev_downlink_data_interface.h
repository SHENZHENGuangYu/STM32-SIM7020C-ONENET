#ifndef __NET_DEV_DOWNLINK_DATA_INTERFACE_H
#define __NET_DEV_DOWNLINK_DATA_INTERFACE_H

#include "net_dev_usart_interface.h"



#define Downlink_Data_Buff_Size 500


typedef struct
{
  char DataStart;
  char DataRecvOK;
  char *DataBuff;
  unsigned int DataLengthCnt;
} NetDev_DownlinkData_TypeDef; 


extern NetDev_DownlinkData_TypeDef NetDev_DownlinkData;


void NetDev_DownlinkData_Init(void);

void NetDev_DownlinkData_Receive( PrimaryUsartRecvData_TypeDef *PrimaryUsartRecvData, 
                                  NetDev_DownlinkData_TypeDef *NetDev_DownlinkData, 
                                  char CurrentRecvByte);

#endif