#ifndef __NET_DEV_TCP_INTERFACE_H
#define __NET_DEV_TCP_INTERFACE_H


char NetDev_Init(void);
char NetDev_TCP_Connect(char *ip_address, char *port);
char NetDev_TCP_Shut(void);
char NetDev_TCP_SendData(char *data, unsigned int data_len);
char NetDev_TCP_Connect_Status(void);

#endif