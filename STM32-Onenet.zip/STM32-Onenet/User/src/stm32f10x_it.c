/**
  ******************************************************************************
  * @file    USART/Interrupt/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x.h"
#include "stm32_usart.h" 

#include "string.h"
#include <stdio.h>

#include "onenet_edp_app.h"
#include "onenet_edp_base.h"

#include "net_dev_usart_data_recv_interface.h"
#include "delay_interface.h"

#include "main.h"
    
/** @addtogroup STM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup USART_Interrupt
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned int SecondCnt = 0; //�������
unsigned int mSecondCnt = 0; //���������



/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}

/**-----------------------------------------------------------------------------
  * @���  ����1�жϴ��������������������ݽ���
  * @����  
  * @����  
  */
void USART1_IRQHandler(void)
{
  
  unsigned char current_recv_byte = 0;
  
  if (USART_GetFlagStatus(USART1, USART_FLAG_PE) != RESET)
   {
       USART_ReceiveData(USART1);
     USART_ClearFlag(USART1, USART_FLAG_PE);
   }
    
   if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
   {
       USART_ReceiveData(USART1);
     USART_ClearFlag(USART1, USART_FLAG_ORE);
   }
    
    if (USART_GetFlagStatus(USART1, USART_FLAG_FE) != RESET)
   {
       USART_ReceiveData(USART1);
      USART_ClearFlag(USART1, USART_FLAG_FE);
   }


  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    /* ���жϱ�־ */
    USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    USART_ClearFlag(USART1, USART_FLAG_RXNE);
    
    current_recv_byte = USART_ReceiveData(USART1);
    
#ifdef USE_USART_DEBUG
    
    STM32_USART2_SendByte(current_recv_byte); //������
    
#endif
    

    NetDev_UsartData_Receive(&PrimaryUsartRecvData, &NetDev_AtCmd, &NetDev_DownlinkData, current_recv_byte);
    
    Onenet_DownlinkData_PrimaryProcess(&OnenetEDPDevice, &NetDev_DownlinkData);

  }
}





/**-----------------------------------------------------------------------------
  * @���  ��ʱ��2�жϴ��������������������ݽ��ճ�ʱ��������ʱ
  * @����  
  * @����  
  */
void TIM2_IRQHandler(void)
{
   if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
   {
     //���TIM2���жϴ�����λ
     TIM_ClearITPendingBit(TIM2, TIM_FLAG_Update);
     TIM_ClearFlag(TIM2, TIM_FLAG_Update);  //�������жϱ�־
     
       SecondCnt++;
     if(SecondCnt == 0xffff)
       
       SecondCnt = 0;
    
     if(SecondCnt % 10 == 0)//10�����滻�ɴ�������ȡ���ݵ�����
     {
       SensorDataGetFlag = 1;
     }
     
     if(1)
     {
       if( SecondCnt % OnenetEDPDevice.PingCycle == 0 && OnenetEDPDevice.TimeToPing != 1 )
       {
         OnenetEDPDevice.TimeToPing = 1;
       }
     
       if(SecondCnt % 10  == 0 && OnenetEDPDevice.TimeToUploadDataStreams != 1)//10���Ըĳ��ϴ�����������������
       {
         OnenetEDPDevice.TimeToUploadDataStreams = 1;
       }
     }
    
   }
 
}

/**-----------------------------------------------------------------------------
  * @���  ��ʱ��3�жϴ���������������ʱ�������ݵ��������ʱ
  * @����  
  * @����  
  */

void TIM3_IRQHandler(void)
{
  
   if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
   {
     //���TIM3���жϴ�����λ
     TIM_ClearITPendingBit(TIM3, TIM_FLAG_Update);
     TIM_ClearFlag(TIM3, TIM_FLAG_Update);  //�������жϱ�־
     
    
     
     

   }
}


/**-----------------------------------------------------------------------------
  * @���  ��ʱ��4�жϴ�������
  * @����  
  * @����  
  */

void TIM4_IRQHandler(void)
{
  if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)
   {
     //���TIM4���жϴ�����λ
     TIM_ClearITPendingBit(TIM4, TIM_FLAG_Update);
     TIM_ClearFlag(TIM4, TIM_FLAG_Update);  //�������жϱ�־
    
       
   } 
}


/**-----------------------------------------------------------------------------
  * @���  �ⲿ�ж�0�жϴ�������
  * @����  
  * @����  
  */
void EXTI0_IRQHandler(void)
{

  if( EXTI_GetITStatus(EXTI_Line0) != RESET )
  {
    EXTI_ClearITPendingBit(EXTI_Line0); //���LINE0�ϵ��жϱ�־λ
    EXTI_ClearFlag(EXTI_Line0);
      
  }
}

/**-----------------------------------------------------------------------------
  * @���  �ⲿ�ж�1�жϴ�������
  * @����  
  * @����  
  */
void EXTI1_IRQHandler(void)
{
  
  if( EXTI_GetITStatus(EXTI_Line1) != RESET )
  {
    EXTI_ClearITPendingBit(EXTI_Line1); //���LINE1�ϵ��жϱ�־λ
    EXTI_ClearFlag(EXTI_Line1);
    
   
    
  }
}
/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
